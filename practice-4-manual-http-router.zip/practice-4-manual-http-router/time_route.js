const http = require('http');

// Беремо порт з першого аргументу командного рядка
const port = process.argv[2];

// Створюємо HTTP-сервер
const server = http.createServer((req, res) => {
  // Маршрут GET /time
  if (req.method === 'GET' && req.url === '/time') {
    const responseBody = {
      now: new Date().toISOString()
    };

    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(responseBody));
  }
});

// Запускаємо сервер
server.listen(port);
