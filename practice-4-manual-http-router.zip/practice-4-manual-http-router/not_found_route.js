const http = require('http');

// Беремо порт з першого аргументу командного рядка
const port = process.argv[2];

// Створюємо HTTP-сервер
const server = http.createServer((req, res) => {
  // Для будь-якого невідомого маршруту або методу повертаємо 404
  res.statusCode = 404;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify({ error: 'Not found' }));
});

// Запускаємо сервер
server.listen(port);
