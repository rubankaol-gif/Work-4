# Practice 4 - Manual HTTP Router

Готові файли для вправ 4.1–4.5 з модуля eu-node-basics-workshop.

## Файли

1. `solution.js` — 4.1 ROOT ROUTE
2. `time_route.js` — 4.2 TIME ROUTE
3. `echo_route.js` — 4.3 ECHO ROUTE
4. `sum_route.js` — 4.4 SUM ROUTE
5. `not_found_route.js` — 4.5 NOT FOUND ROUTE

## Запуск

Приклад запуску:

```bash
node solution.js 3000
```

## Перевірка

```bash
eu-node-basics verify 1 solution.js
eu-node-basics verify 2 time_route.js
eu-node-basics verify 3 echo_route.js
eu-node-basics verify 4 sum_route.js
eu-node-basics verify 5 not_found_route.js
```

Або запустити:

```bash
eu-node-basics
```

Потім обрати Practice 4 і виконати Verify для кожної вправи.
