const http = require('http');

// Беремо порт з першого аргументу командного рядка
const port = process.argv[2];

// Створюємо HTTP-сервер
const server = http.createServer((req, res) => {
  // Створюємо URL-об'єкт, щоб читати шлях і query-параметри
  const url = new URL(req.url, `http://localhost:${port}`);

  // Маршрут GET /sum?a=<number>&b=<number>
  if (req.method === 'GET' && url.pathname === '/sum') {
    const aParam = url.searchParams.get('a');
    const bParam = url.searchParams.get('b');

    const a = Number(aParam);
    const b = Number(bParam);

    // Перевіряємо, що параметри не відсутні і є числами
    if (aParam === null || bParam === null || Number.isNaN(a) || Number.isNaN(b)) {
      res.statusCode = 400;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ error: 'Invalid numbers' }));
      return;
    }

    // Якщо все правильно — повертаємо суму
    res.statusCode = 200;
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({ sum: a + b }));
  }
});

// Запускаємо сервер
server.listen(port);
