const http = require('http');

// Беремо порт з першого аргументу командного рядка
const port = process.argv[2];

// Створюємо HTTP-сервер
const server = http.createServer((req, res) => {
  // Створюємо URL-об'єкт, щоб зручно читати шлях і query-параметри
  const url = new URL(req.url, `http://localhost:${port}`);

  // Маршрут GET /echo?msg=...
  if (req.method === 'GET' && url.pathname === '/echo') {
    const message = url.searchParams.get('msg') || '';

    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    res.end(message);
  }
});

// Запускаємо сервер
server.listen(port);
